"""Fix skush account: password, active, tenant_admin role."""
from __future__ import annotations

import asyncio
from uuid import UUID

from sqlalchemy import select

from app.core.security import hash_password, verify_password
from app.db.session import AsyncSessionLocal
from app.models.tenant import Role, User, UserRole

EMAIL = "skush@indosakura.com"
PASSWORD = "DemoPass123!"


async def main() -> None:
    async with AsyncSessionLocal() as session:
        user = (await session.execute(select(User).where(User.email == EMAIL))).scalar_one_or_none()
        if not user:
            print("USER_NOT_FOUND")
            return

        user.email = EMAIL.strip().lower()
        user.hashed_password = hash_password(PASSWORD)
        user.is_active = True
        await session.flush()

        admin_role = (
            await session.execute(select(Role).where(Role.code == "tenant_admin"))
        ).scalar_one_or_none()
        if not admin_role:
            print("tenant_admin role missing")
            return

        existing = (
            await session.execute(
                select(UserRole).where(UserRole.user_id == user.id, UserRole.role_id == admin_role.id)
            )
        ).scalar_one_or_none()
        if not existing:
            session.add(UserRole(user_id=user.id, role_id=admin_role.id, tenant_id=user.tenant_id))
            print("added tenant_admin role")

        await session.commit()
        await session.refresh(user)
        ok = verify_password(PASSWORD, user.hashed_password or "")
        print("password_ok", ok)
        print("email", user.email)
        print("tenant", user.tenant_id)
        print("active", user.is_active)


if __name__ == "__main__":
    asyncio.run(main())
