import type { NextConfig } from "next";

const apiProxyTarget =
    process.env.NEXT_PUBLIC_API_BASE_URI ||
    process.env.NEXT_PUBLIC_API_BASE_URL ||
    "http://localhost:8000";

const nextConfig: NextConfig = {
    async rewrites() {
        return [
            { source: "/brand_space/:brandSlug/edit", destination: "/brand_space/edit/:brandSlug" },
            { source: "/brand_space/:brandSlug/view", destination: "/brand_space/view/:brandSlug" },
            { source: "/brand_space/:brandSlug/sharing", destination: "/brand_space/sharing/:brandSlug" },
            // Dev proxy: browser calls same-origin /api/* — Next forwards to the configured backend.
            // Avoids axios "Network Error" from localhost → IP HTTPS cross-origin TLS issues.
            { source: "/api/:path*", destination: `${apiProxyTarget}/api/:path*` },
            { source: "/storage/:path*", destination: `${apiProxyTarget}/storage/:path*` },
        ];
    },
    // Allow Cloudflare quick tunnels to hit the Next.js dev server without "Unauthorized".
    allowedDevOrigins: [
        "*.trycloudflare.com",
        "storm-exams-this-plane.trycloudflare.com",
        "appreciation-ten-vii-rarely.trycloudflare.com",
    ],
    images: {
        remotePatterns: [
            {
                protocol: "http",
                hostname: "localhost",
                port: "8000",
                pathname: "/api/v1/storage/**",
            },
            {
                protocol: "http",
                hostname: "localhost",
                port: "8000",
                pathname: "/storage/**",
            },
            {
                protocol: "https",
                hostname: "*.trycloudflare.com",
                pathname: "/storage/**",
            },
            {
                protocol: "https",
                hostname: "*.trycloudflare.com",
                pathname: "/api/v1/storage/**",
            },
        ],
    },
};

export default nextConfig;
