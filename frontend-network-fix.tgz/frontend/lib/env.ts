export const isDev = process.env.NEXT_PUBLIC_ENV === "development";
export const isProd = process.env.NEXT_PUBLIC_ENV === "production";

function stripTrailingSlash(value: string) {
  return value.endsWith("/") ? value.slice(0, -1) : value;
}

function stripApiPrefix(value: string) {
  return value.replace(/\/api\/v1\/?$/i, "");
}

const configuredApiValue =
  process.env.NEXT_PUBLIC_API_BASE_URI ||
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  "http://localhost:8000";

const configuredServerApiValue =
  process.env.SERVER_API_BASE_URI ||
  process.env.INTERNAL_API_BASE_URI ||
  process.env.API_INTERNAL_ORIGIN ||
  configuredApiValue;

// Browser always uses same-origin /api/* (nginx proxies to backend in prod;
// next.config rewrites proxy in local dev). Avoids baked-in localhost:8000 causing Network Error.
export const apiOrigin =
  typeof window !== "undefined"
    ? ""
    : stripTrailingSlash(stripApiPrefix(configuredApiValue));
export const apiBasePath = `${apiOrigin || ""}/api/v1`;
export const serverApiOrigin = stripTrailingSlash(stripApiPrefix(configuredServerApiValue));
