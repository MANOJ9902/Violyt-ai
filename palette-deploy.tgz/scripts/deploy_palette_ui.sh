#!/bin/bash
set -euo pipefail

# Deploy 3-column Brand Space palette UI + backend palette isolation fixes.
ARCHIVE="${1:-/home/ubuntu/palette-deploy.tgz}"
REPO="${REPO:-/home/ubuntu/Violyt_Repo}"

echo "extracting $ARCHIVE into $REPO"
mkdir -p "$REPO"
tar -xzf "$ARCHIVE" -C "$REPO"

BACKEND_FILES=(
  app/services/brand_visual_pack.py
  app/services/data_validation.py
)

for c in violyt-deploy-api-1 violyt-deploy-worker-1; do
  for f in "${BACKEND_FILES[@]}"; do
    sudo docker exec "$c" mkdir -p "/app/$(dirname "$f")"
    sudo docker cp "$REPO/$f" "$c:/app/$f"
  done
  echo "backend_patched_$c"
done

cd /home/ubuntu/violyt-deploy
sudo docker compose restart api worker
sleep 14

echo "rebuilding frontend image"
cd "$REPO"
sudo docker build -t violyt-frontend:local -f frontend/Dockerfile frontend
cd /home/ubuntu/violyt-deploy
sudo docker compose up -d frontend
sleep 8

sudo docker exec -i violyt-deploy-api-1 python - <<'PY'
from app.services.brand_visual_pack import build_visual_pack

pack = build_visual_pack(
    brand_id="test",
    brand_name="Jiraaf",
    resolved_brand_context={
        "brand_name": "Jiraaf",
        "visual_identity": {
            "brand_color_palette": {
                "primary": "#3D3DBE",
                "secondary": "#FFCBCB",
                "additional": [
                    {"role": "Accent", "name": "Mint Green", "hex": "#00CB91"},
                    {"role": "Primary Tint", "name": "Soft Lilac", "hex": "#EEE1FA"},
                ],
            }
        },
    },
)
assert pack.primary == "#3D3DBE", pack.primary
assert pack.secondary == "#FFCBCB", pack.secondary
assert pack.accent == "#00CB91", pack.accent
assert pack.card == "#EEE1FA", pack.card
lock = pack.palette_lock()
assert "#3D3DBE" in lock and "#FFCBCB" in lock and "#00CB91" in lock
print("deploy_palette_smoke=ok")
PY

curl -sk -o /dev/null -w 'health=%{http_code} frontend=%{http_code}\n' \
  http://127.0.0.1:8000/health \
  https://127.0.0.1:3001/ 2>/dev/null || true

sudo docker ps --format '{{.Names}} {{.Status}}' | grep -E 'api-1|worker-1|frontend-1'
echo "deploy_done"
