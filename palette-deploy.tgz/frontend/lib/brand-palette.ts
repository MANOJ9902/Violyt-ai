import { BRAND_PALETTE_ROLE_OPTIONS } from "@/lib/brand-space-options";
import type { BrandPaletteColorRow } from "@/types/brand-space.types";

const PRIMARY_ROLE = "Primary Colour";
const SECONDARY_ROLE = "Secondary Colour";

const KNOWN_ROLES = new Set(
  BRAND_PALETTE_ROLE_OPTIONS.map((role) => role.toLowerCase()).concat([
    "primary color",
    "secondary color",
    "primary",
    "secondary",
  ]),
);

export function isKnownPaletteRole(value: string) {
  return KNOWN_ROLES.has(value.trim().toLowerCase());
}

function normalizeRoleLabel(value: string) {
  const trimmed = value.trim();
  if (!trimmed) {
    return "";
  }
  const lower = trimmed.toLowerCase();
  if (lower === "primary" || lower === "primary color") {
    return PRIMARY_ROLE;
  }
  if (lower === "secondary" || lower === "secondary color") {
    return SECONDARY_ROLE;
  }
  const match = BRAND_PALETTE_ROLE_OPTIONS.find((role) => role.toLowerCase() === lower);
  return match || trimmed;
}

function defaultPaletteRows(): BrandPaletteColorRow[] {
  return [
    { role: PRIMARY_ROLE, colourName: "", hex: "" },
    { role: SECONDARY_ROLE, colourName: "", hex: "" },
  ];
}

function toRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function colourNameFromItem(item: Record<string, unknown>, roleLabel: string) {
  const explicit = String(item.colour_name || item.color_name || "").trim();
  if (explicit) {
    return explicit;
  }
  const name = String(item.name || "").trim();
  if (!name || normalizeRoleLabel(name) === roleLabel) {
    return "";
  }
  return isKnownPaletteRole(name) ? "" : name;
}

export function paletteColorsFromApi(colorPalette: Record<string, unknown>): BrandPaletteColorRow[] {
  const primaryHex = String(colorPalette.primary || "").trim();
  const secondaryHex = String(colorPalette.secondary || "").trim();
  const additionalRaw = Array.isArray(colorPalette.additional) ? colorPalette.additional : [];

  const additionalRows = additionalRaw
    .map((item) => toRecord(item))
    .filter((item) => String(item.hex || item.hex_code || "").trim())
    .map((item) => {
      const hex = String(item.hex || item.hex_code || "").trim();
      const roleLabel = normalizeRoleLabel(String(item.role || item.name || ""));
      return {
        role: roleLabel,
        colourName: colourNameFromItem(item, roleLabel),
        hex,
      };
    });

  const hasStructuredRoles = additionalRows.some((row) => row.role && isKnownPaletteRole(row.role));
  if (hasStructuredRoles) {
    const rows = [...additionalRows];
    if (primaryHex && !rows.some((row) => row.role === PRIMARY_ROLE)) {
      rows.unshift({ role: PRIMARY_ROLE, colourName: "", hex: primaryHex });
    }
    if (secondaryHex && !rows.some((row) => row.role === SECONDARY_ROLE)) {
      const primaryIndex = rows.findIndex((row) => row.role === PRIMARY_ROLE);
      rows.splice(primaryIndex >= 0 ? primaryIndex + 1 : 0, 0, {
        role: SECONDARY_ROLE,
        colourName: "",
        hex: secondaryHex,
      });
    }
    return rows.length ? rows : defaultPaletteRows();
  }

  const rows: BrandPaletteColorRow[] = [
    { role: PRIMARY_ROLE, colourName: "", hex: primaryHex },
    { role: SECONDARY_ROLE, colourName: "", hex: secondaryHex },
    ...additionalRows.map((row) => ({
      role: row.role && isKnownPaletteRole(row.role) ? row.role : "",
      colourName: row.colourName || (row.role && !isKnownPaletteRole(row.role) ? row.role : ""),
      hex: row.hex,
    })),
  ];

  const filledRows = rows.filter((row) => row.role || row.colourName || row.hex);
  return filledRows.length ? filledRows : defaultPaletteRows();
}

export function paletteColorsToApi(paletteColors: BrandPaletteColorRow[]) {
  let primary = "";
  let secondary = "";
  const additional: Array<{ role: string; name: string; hex: string }> = [];

  for (const row of paletteColors) {
    const hex = row.hex.trim();
    if (!hex) {
      continue;
    }
    const role = normalizeRoleLabel(row.role);
    const colourName = row.colourName.trim();

    if (role === PRIMARY_ROLE && !primary) {
      primary = hex;
    } else if (role === SECONDARY_ROLE && !secondary) {
      secondary = hex;
    }

    additional.push({
      role,
      name: colourName || role,
      hex,
    });
  }

  return { primary, secondary, additional };
}

export function paletteRowFromUploadEntry(entry: Record<string, unknown>): BrandPaletteColorRow {
  const roleRaw = String(entry.role || entry.color_role || "").trim().toLowerCase();
  const name = String(entry.color_name || entry.name || "").trim();
  const hex = String(entry.hex_code || entry.hex || "").trim();

  let role = "";
  if (roleRaw === "primary") {
    role = PRIMARY_ROLE;
  } else if (roleRaw === "secondary") {
    role = SECONDARY_ROLE;
  } else if (isKnownPaletteRole(name)) {
    role = normalizeRoleLabel(name);
  } else if (isKnownPaletteRole(roleRaw)) {
    role = normalizeRoleLabel(roleRaw);
  }

  return {
    role,
    colourName: role && normalizeRoleLabel(name) === role ? "" : name,
    hex,
  };
}

export { PRIMARY_ROLE, SECONDARY_ROLE };
